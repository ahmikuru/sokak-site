@echo off
cd /d %~dp0
if not exist .env (
  node scripts\setup.js
)
if not exist node_modules (
  npm install
)
npm run dev
pause
