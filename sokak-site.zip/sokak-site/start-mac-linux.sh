#!/usr/bin/env sh
cd "$(dirname "$0")"
if [ ! -f .env ]; then
  node scripts/setup.js
fi
if [ ! -d node_modules ]; then
  npm install
fi
npm run dev
