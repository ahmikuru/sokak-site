require('dotenv').config();

const path = require('path');
const express = require('express');
const session = require('express-session');
const SQLiteStoreFactory = require('connect-sqlite3');
const helmet = require('helmet');
const compression = require('compression');
const morgan = require('morgan');
const multer = require('multer');

const { initDb, dataDir } = require('./db');
const { ensureToken } = require('./csrf');
const { attachAdmin } = require('./auth');
const { attachFlash, publicDir } = require('./utils');
const publicRoutes = require('./routes/public');
const adminRoutes = require('./routes/admin');
const apiRoutes = require('./routes/api');

initDb();

const app = express();
const SQLiteStore = SQLiteStoreFactory(session);
const isProduction = process.env.NODE_ENV === 'production';
const baseUrl = process.env.BASE_URL || '';
const sessionSecret = process.env.SESSION_SECRET || 'dev-only-change-me';

if (sessionSecret === 'dev-only-change-me') {
  console.warn('[UYARI] SESSION_SECRET .env icinde ayarlanmamis. Yerel test icin calisir, internete acmadan once degistir.');
}

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));
app.disable('x-powered-by');

app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      scriptSrc: ["'self'"],
      styleSrc: ["'self'", "'unsafe-inline'"],
      imgSrc: ["'self'", 'data:', 'https:'],
      mediaSrc: ["'self'", 'https:'],
      connectSrc: ["'self'"],
      objectSrc: ["'none'"],
      baseUri: ["'self'"],
      frameAncestors: ["'self'"],
      formAction: ["'self'"]
    }
  },
  crossOriginResourcePolicy: { policy: 'cross-origin' }
}));
app.use(compression());
app.use(morgan(isProduction ? 'combined' : 'dev'));

app.use(express.urlencoded({ extended: false, limit: '1mb' }));
app.use(express.json({ limit: '1mb' }));
app.use(express.static(publicDir, {
  maxAge: isProduction ? '7d' : 0,
  etag: true
}));

app.use(session({
  store: new SQLiteStore({ db: 'sessions.sqlite', dir: dataDir }),
  secret: sessionSecret,
  resave: false,
  saveUninitialized: false,
  cookie: {
    httpOnly: true,
    sameSite: 'lax',
    secure: isProduction && baseUrl.startsWith('https://'),
    maxAge: 1000 * 60 * 60 * 24 * 14
  }
}));

app.use(attachFlash);
app.use(ensureToken);
app.use(attachAdmin);

app.use('/api', apiRoutes);
app.use('/admin', adminRoutes);
app.use('/', publicRoutes);

app.use((req, res) => {
  res.status(404).render('404');
});

app.use((err, req, res, next) => {
  console.error(err);
  let message = 'Bir hata oldu.';
  let status = 500;
  if (err instanceof multer.MulterError) {
    status = 400;
    message = err.code === 'LIMIT_FILE_SIZE' ? 'Dosya boyutu fazla büyük.' : err.message;
  } else if (err && err.message) {
    status = 400;
    message = err.message;
  }
  if (req.accepts(['html', 'json']) === 'json') {
    return res.status(status).json({ ok: false, error: message });
  }
  res.status(status).render('error', { message });
});

const port = Number(process.env.PORT || 3000);
const host = process.env.HOST || '127.0.0.1';
app.listen(port, host, () => {
  console.log(`Sokak Kolaj Site hazir: http://${host}:${port}`);
  console.log(`Admin panel: http://${host}:${port}/admin`);
});
