const crypto = require('crypto');
const { getDb, getSetting } = require('./db');

const AUTH_ENDPOINT = 'https://accounts.spotify.com/authorize';
const TOKEN_ENDPOINT = 'https://accounts.spotify.com/api/token';
const API_ENDPOINT = 'https://api.spotify.com/v1';

const scopes = [
  'user-read-currently-playing',
  'user-read-recently-played',
  'playlist-read-private',
  'playlist-read-collaborative'
];

let cache = null;
let cacheAt = 0;
const CACHE_MS = 20 * 1000;

function getRedirectUri() {
  if (process.env.SPOTIFY_REDIRECT_URI) return process.env.SPOTIFY_REDIRECT_URI;
  const base = process.env.BASE_URL || `http://127.0.0.1:${process.env.PORT || 3000}`;
  return `${base.replace(/\/$/, '')}/admin/spotify/callback`;
}

function credentialsAvailable() {
  return Boolean(process.env.SPOTIFY_CLIENT_ID && process.env.SPOTIFY_CLIENT_SECRET);
}

function getTokenRow() {
  return getDb().prepare('SELECT * FROM spotify_tokens WHERE id = 1').get();
}

function isConnected() {
  const row = getTokenRow();
  return Boolean(row && row.refresh_token);
}

function clearTokens() {
  getDb().prepare('DELETE FROM spotify_tokens WHERE id = 1').run();
  cache = null;
  cacheAt = 0;
}

function saveTokens(tokens) {
  const existing = getTokenRow();
  const refresh = tokens.refresh_token || (existing && existing.refresh_token) || '';
  const access = tokens.access_token || (existing && existing.access_token) || '';
  const expiresIn = Number(tokens.expires_in || 3600);
  const expiresAt = Date.now() + expiresIn * 1000 - 60 * 1000;
  getDb().prepare(`
    INSERT INTO spotify_tokens (id, access_token, refresh_token, expires_at, updated_at)
    VALUES (1, @access, @refresh, @expiresAt, CURRENT_TIMESTAMP)
    ON CONFLICT(id) DO UPDATE SET
      access_token = excluded.access_token,
      refresh_token = excluded.refresh_token,
      expires_at = excluded.expires_at,
      updated_at = CURRENT_TIMESTAMP
  `).run({ access, refresh, expiresAt });
  cache = null;
  cacheAt = 0;
}

function buildAuthUrl(state) {
  const params = new URLSearchParams({
    response_type: 'code',
    client_id: process.env.SPOTIFY_CLIENT_ID,
    scope: scopes.join(' '),
    redirect_uri: getRedirectUri(),
    state,
    show_dialog: 'true'
  });
  return `${AUTH_ENDPOINT}?${params.toString()}`;
}

function randomState() {
  return crypto.randomBytes(20).toString('hex');
}

async function tokenRequest(params) {
  if (!credentialsAvailable()) throw new Error('Spotify CLIENT_ID ve CLIENT_SECRET eksik.');
  const basic = Buffer.from(`${process.env.SPOTIFY_CLIENT_ID}:${process.env.SPOTIFY_CLIENT_SECRET}`).toString('base64');
  const response = await fetch(TOKEN_ENDPOINT, {
    method: 'POST',
    headers: {
      Authorization: `Basic ${basic}`,
      'Content-Type': 'application/x-www-form-urlencoded'
    },
    body: new URLSearchParams(params)
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) {
    throw new Error(data.error_description || data.error || 'Spotify token alınamadı.');
  }
  saveTokens(data);
  return data;
}

async function exchangeCode(code) {
  return tokenRequest({
    grant_type: 'authorization_code',
    code,
    redirect_uri: getRedirectUri()
  });
}

async function refreshAccessToken() {
  const row = getTokenRow();
  if (!row || !row.refresh_token) return null;
  await tokenRequest({
    grant_type: 'refresh_token',
    refresh_token: row.refresh_token
  });
  return getTokenRow();
}

async function getAccessToken() {
  if (!credentialsAvailable()) return null;
  const row = getTokenRow();
  if (!row || !row.refresh_token) return null;
  if (row.access_token && Number(row.expires_at) > Date.now()) return row.access_token;
  const refreshed = await refreshAccessToken();
  return refreshed && refreshed.access_token;
}

async function spotifyApi(path, retry = true) {
  const token = await getAccessToken();
  if (!token) return { status: 401, data: null };
  const response = await fetch(`${API_ENDPOINT}${path}`, {
    headers: { Authorization: `Bearer ${token}` }
  });
  if (response.status === 401 && retry) {
    await refreshAccessToken();
    return spotifyApi(path, false);
  }
  if (response.status === 204) return { status: 204, data: null };
  const data = await response.json().catch(() => null);
  if (!response.ok) {
    return { status: response.status, data, error: (data && (data.error && data.error.message)) || response.statusText };
  }
  return { status: response.status, data };
}

function imageFrom(images) {
  if (!Array.isArray(images) || images.length === 0) return '';
  return images[0].url || '';
}

function mapTrack(item) {
  if (!item) return null;
  const isEpisode = item.type === 'episode';
  const album = item.album || {};
  return {
    type: item.type || 'track',
    name: item.name || '',
    artist: isEpisode ? (item.show && item.show.name) || 'Podcast' : (item.artists || []).map((a) => a.name).join(', '),
    album: isEpisode ? '' : album.name || '',
    image: imageFrom(isEpisode ? item.images : album.images),
    url: item.external_urls && item.external_urls.spotify ? item.external_urls.spotify : ''
  };
}

function mapPlaylist(item) {
  if (!item) return null;
  return {
    id: item.id,
    name: item.name || '',
    image: imageFrom(item.images),
    owner: item.owner && item.owner.display_name ? item.owner.display_name : '',
    url: item.external_urls && item.external_urls.spotify ? item.external_urls.spotify : '',
    total: item.tracks && typeof item.tracks.total === 'number' ? item.tracks.total : null,
    public: item.public
  };
}

function playlistIdFrom(value) {
  const raw = String(value || '').trim();
  if (!raw) return '';
  const spotifyUrl = raw.match(/playlist\/([A-Za-z0-9]+)/);
  if (spotifyUrl) return spotifyUrl[1];
  const spotifyUri = raw.match(/spotify:playlist:([A-Za-z0-9]+)/);
  if (spotifyUri) return spotifyUri[1];
  return raw.replace(/[^A-Za-z0-9]/g, '');
}

async function getStatus(settings = {}) {
  if (!credentialsAvailable()) {
    return { connected: false, reason: 'credentials_missing' };
  }
  if (!isConnected()) {
    return { connected: false, reason: 'not_connected' };
  }
  if (cache && Date.now() - cacheAt < CACHE_MS) return cache;

  const result = { connected: true, current: null, recent: [], playlists: [], featuredPlaylist: null, updatedAt: new Date().toISOString() };

  const [current, recent, playlists] = await Promise.all([
    spotifyApi('/me/player/currently-playing?additional_types=track,episode'),
    spotifyApi('/me/player/recently-played?limit=6'),
    spotifyApi('/me/playlists?limit=6')
  ]);

  if (current.status === 200 && current.data && current.data.item) {
    result.current = {
      ...mapTrack(current.data.item),
      isPlaying: Boolean(current.data.is_playing),
      progressMs: current.data.progress_ms || 0
    };
  }

  if (recent.status === 200 && recent.data && Array.isArray(recent.data.items)) {
    result.recent = recent.data.items.map((row) => mapTrack(row.track)).filter(Boolean);
  }

  if (playlists.status === 200 && playlists.data && Array.isArray(playlists.data.items)) {
    result.playlists = playlists.data.items.map(mapPlaylist).filter(Boolean);
  }

  const configuredPlaylist = playlistIdFrom(settings.spotify_playlist_id || getSetting('spotify_playlist_id', ''));
  if (configuredPlaylist) {
    const one = await spotifyApi(`/playlists/${configuredPlaylist}?fields=id,name,images,owner(display_name),external_urls,tracks(total),public`);
    if (one.status === 200 && one.data) result.featuredPlaylist = mapPlaylist(one.data);
  }

  cache = result;
  cacheAt = Date.now();
  return result;
}

module.exports = {
  scopes,
  credentialsAvailable,
  isConnected,
  getRedirectUri,
  randomState,
  buildAuthUrl,
  exchangeCode,
  clearTokens,
  getStatus,
  playlistIdFrom
};
