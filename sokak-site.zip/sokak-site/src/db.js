const fs = require('fs');
const path = require('path');
const Database = require('better-sqlite3');

const rootDir = path.join(__dirname, '..');
const dataDir = path.join(rootDir, 'data');
const dbPath = process.env.DB_PATH || path.join(dataDir, 'site.sqlite');

let db;

function nowIso() {
  return new Date().toISOString();
}

function getDb() {
  if (!db) throw new Error('Database not initialized. Call initDb() first.');
  return db;
}

const defaultSettings = {
  site_title: 'mySOKAKUS',
  site_tagline: 'Get your shout on the web.',
  header_micro: 'JOIN / LOGIN / ABOUT',
  search_placeholder: 'search the block...',
  hero_name: 'SENİN ADIN',
  hero_kicker: 'KRYSTAL SHIP MODE',
  hero_status: 'Status: online, dağınık, gerçek',
  hero_here_for: 'Here for: fotoğraf, müzik, mesaj, shout',
  hero_body: 'Bu alanı admin panelinden değiştir. Kolajdaki bütün fotoğrafları, yazıları ve linkleri tek tek yönetebilirsin.',
  hero_quote: 'Sokak defteri açık. Yaz, bırak, kaybol.',
  bio_title: 'WHO I AM',
  bio_text: 'Kendi cümlelerini buraya yaz. Kısa biyografi, manifesto, günlük notu veya duyuru olabilir.',
  wall_title: 'HERKESE AÇIK DUVAR',
  wall_intro: 'Anonim ya da isimle bir şey bırak. İstersen fotoğraf da at.',
  private_message_title: 'BANA GİZLİ MESAJ AT',
  private_message_intro: 'Bu mesajlar sadece admin panelinde görünür.',
  spotify_title: 'ŞU AN NE DİNLİYORUM?',
  payment_title: 'DESTEK / IBAN',
  iban: 'TR00 0000 0000 0000 0000 0000 00',
  easy_address: 'kolayadres@ornek.com',
  payment_note: 'IBAN ve Kolay Adres alanlarını admin panelinden değiştir.',
  footer_note: 'no rules, just noise.',
  wall_auto_approve: 'true',
  allow_wall_images: 'true',
  allow_messages: 'true',
  spotify_playlist_id: '',
  admin_brand_note: 'kolaj kontrol odası'
};

function schema() {
  return `
  CREATE TABLE IF NOT EXISTS admins (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT NOT NULL UNIQUE,
    password_hash TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS settings (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS collage_items (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL DEFAULT '',
    subtitle TEXT NOT NULL DEFAULT '',
    body TEXT NOT NULL DEFAULT '',
    image_path TEXT NOT NULL DEFAULT '',
    link_url TEXT NOT NULL DEFAULT '',
    x REAL NOT NULL DEFAULT 10,
    y REAL NOT NULL DEFAULT 10,
    w REAL NOT NULL DEFAULT 26,
    rotation REAL NOT NULL DEFAULT 0,
    z INTEGER NOT NULL DEFAULT 1,
    variant TEXT NOT NULL DEFAULT 'photo',
    enabled INTEGER NOT NULL DEFAULT 1,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS social_links (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    service TEXT NOT NULL DEFAULT '',
    label TEXT NOT NULL DEFAULT '',
    url TEXT NOT NULL DEFAULT '',
    sort_order INTEGER NOT NULL DEFAULT 0,
    enabled INTEGER NOT NULL DEFAULT 1
  );

  CREATE TABLE IF NOT EXISTS wall_posts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL DEFAULT 'Anonim',
    message TEXT NOT NULL DEFAULT '',
    image_path TEXT NOT NULL DEFAULT '',
    approved INTEGER NOT NULL DEFAULT 1,
    hidden INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS private_messages (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL DEFAULT 'Anonim',
    contact TEXT NOT NULL DEFAULT '',
    message TEXT NOT NULL DEFAULT '',
    archived INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS background_tracks (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL DEFAULT '',
    artist TEXT NOT NULL DEFAULT '',
    audio_path TEXT NOT NULL DEFAULT '',
    external_url TEXT NOT NULL DEFAULT '',
    is_active INTEGER NOT NULL DEFAULT 0,
    volume REAL NOT NULL DEFAULT 0.45,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS spotify_tokens (
    id INTEGER PRIMARY KEY CHECK (id = 1),
    access_token TEXT NOT NULL DEFAULT '',
    refresh_token TEXT NOT NULL DEFAULT '',
    expires_at INTEGER NOT NULL DEFAULT 0,
    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
  );
  `;
}

function seedSettings() {
  const insert = db.prepare('INSERT OR IGNORE INTO settings (key, value) VALUES (?, ?)');
  const tx = db.transaction(() => {
    Object.entries(defaultSettings).forEach(([key, value]) => insert.run(key, String(value)));
  });
  tx();
}

function seedCollage() {
  const count = db.prepare('SELECT COUNT(*) AS count FROM collage_items').get().count;
  if (count > 0) return;
  const insert = db.prepare(`
    INSERT INTO collage_items (title, subtitle, body, x, y, w, rotation, z, variant, enabled)
    VALUES (@title, @subtitle, @body, @x, @y, @w, @rotation, @z, @variant, 1)
  `);
  const items = [
    { title: 'BURAYA FOTO', subtitle: 'admin panelinden yükle', body: 'İlk büyük kolaj fotoğrafı.', x: 4, y: 18, w: 22, rotation: -10, z: 3, variant: 'photo' },
    { title: 'KRYSTAL SHIP', subtitle: 'sokak profili', body: 'Status, mood, kısa notlar ve linkler burada patlar.', x: 50, y: 7, w: 42, rotation: 0, z: 4, variant: 'profile' },
    { title: 'ARKADAŞLAR / KARE', subtitle: 'gürültülü anılar', body: 'Çoklu fotoğraf köşesi.', x: 6, y: 43, w: 36, rotation: 7, z: 2, variant: 'photo' },
    { title: 'SMOKIN\'', subtitle: '', body: 'Büyük sticker yazısı. İstediğin kelimeyle değiştir.', x: 35, y: 56, w: 30, rotation: -8, z: 8, variant: 'sticker' },
    { title: 'MINI POLAROID', subtitle: 'yakın plan', body: '', x: 77, y: 31, w: 17, rotation: 3, z: 6, variant: 'photo' },
    { title: 'GECE NOTU', subtitle: 'public shout', body: 'Ziyaretçilerin bıraktığı yazılar aşağıda görünür.', x: 61, y: 67, w: 28, rotation: 13, z: 5, variant: 'note' },
    { title: 'KAYKAY / KASET', subtitle: 'hareket', body: '', x: 8, y: 70, w: 21, rotation: -16, z: 3, variant: 'photo' }
  ];
  const tx = db.transaction(() => items.forEach((item) => insert.run(item)));
  tx();
}

function seedSocials() {
  const count = db.prepare('SELECT COUNT(*) AS count FROM social_links').get().count;
  if (count > 0) return;
  const insert = db.prepare('INSERT INTO social_links (service, label, url, sort_order, enabled) VALUES (?, ?, ?, ?, 1)');
  const socials = [
    ['instagram', 'Instagram', 'https://instagram.com/', 10],
    ['tiktok', 'TikTok', 'https://tiktok.com/@', 20],
    ['letterboxd', 'Letterboxd', 'https://letterboxd.com/', 30],
    ['discord', 'Discord', 'https://discord.com/users/', 40],
    ['spotify', 'Spotify', 'https://open.spotify.com/', 50]
  ];
  const tx = db.transaction(() => socials.forEach((s) => insert.run(...s)));
  tx();
}

function initDb() {
  fs.mkdirSync(dataDir, { recursive: true });
  db = new Database(dbPath);
  db.pragma('journal_mode = WAL');
  db.pragma('foreign_keys = ON');
  db.exec(schema());
  seedSettings();
  seedCollage();
  seedSocials();
}

function settingsObject() {
  const rows = getDb().prepare('SELECT key, value FROM settings').all();
  return rows.reduce((acc, row) => {
    acc[row.key] = row.value;
    return acc;
  }, {});
}

function getSetting(key, fallback = '') {
  const row = getDb().prepare('SELECT value FROM settings WHERE key = ?').get(key);
  return row ? row.value : fallback;
}

function setSetting(key, value) {
  getDb().prepare(`
    INSERT INTO settings (key, value) VALUES (?, ?)
    ON CONFLICT(key) DO UPDATE SET value = excluded.value
  `).run(key, String(value ?? ''));
}

function setSettings(values) {
  const stmt = getDb().prepare(`
    INSERT INTO settings (key, value) VALUES (?, ?)
    ON CONFLICT(key) DO UPDATE SET value = excluded.value
  `);
  const tx = getDb().transaction((entries) => {
    entries.forEach(([key, value]) => stmt.run(key, String(value ?? '')));
  });
  tx(Object.entries(values));
}

module.exports = {
  initDb,
  getDb,
  settingsObject,
  getSetting,
  setSetting,
  setSettings,
  nowIso,
  rootDir,
  dataDir
};
