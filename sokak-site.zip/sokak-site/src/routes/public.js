const express = require('express');
const rateLimit = require('express-rate-limit');
const { getDb, settingsObject } = require('../db');
const { checkToken } = require('../csrf');
const { imageUpload, publicPathFor, cleanText, flash, formatDate, deleteUpload } = require('../utils');
const spotify = require('../spotify');

const router = express.Router();

const messageLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 8,
  standardHeaders: true,
  legacyHeaders: false,
  message: 'Çok kısa sürede çok fazla mesaj denendi. Biraz sonra tekrar dene.'
});

const wallLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 10,
  standardHeaders: true,
  legacyHeaders: false,
  message: 'Duvara çok hızlı yazıldı. Biraz sonra tekrar dene.'
});

router.get('/', (req, res) => {
  const db = getDb();
  const settings = settingsObject();
  const collage = db.prepare('SELECT * FROM collage_items WHERE enabled = 1 ORDER BY z ASC, id ASC').all();
  const socials = db.prepare('SELECT * FROM social_links WHERE enabled = 1 ORDER BY sort_order ASC, id ASC').all();
  const wallPosts = db.prepare(`
    SELECT * FROM wall_posts
    WHERE approved = 1 AND hidden = 0
    ORDER BY datetime(created_at) DESC
    LIMIT 40
  `).all();
  const activeTrack = db.prepare('SELECT * FROM background_tracks WHERE is_active = 1 ORDER BY id DESC LIMIT 1').get();

  res.render('index', {
    settings,
    collage,
    socials,
    wallPosts,
    activeTrack,
    spotifyReady: spotify.credentialsAvailable() && spotify.isConnected(),
    formatDate
  });
});

router.post('/message', messageLimiter, checkToken, (req, res) => {
  const settings = settingsObject();
  if (settings.allow_messages !== 'true') {
    flash(req, 'bad', 'Mesaj kutusu şu an kapalı.');
    return res.redirect('/#message');
  }
  const name = cleanText(req.body.name, 80) || 'Anonim';
  const contact = cleanText(req.body.contact, 160);
  const message = cleanText(req.body.message, 2500);
  if (!message || message.length < 2) {
    flash(req, 'bad', 'Mesaj alanı boş olamaz.');
    return res.redirect('/#message');
  }
  getDb().prepare('INSERT INTO private_messages (name, contact, message) VALUES (?, ?, ?)').run(name, contact, message);
  flash(req, 'ok', 'Mesajın geldi. Sadece admin panelinde görünecek.');
  res.redirect('/#message');
});

router.post('/wall', wallLimiter, imageUpload.single('image'), checkToken, (req, res) => {
  const settings = settingsObject();
  const name = cleanText(req.body.name, 80) || 'Anonim';
  const message = cleanText(req.body.message, 1200);
  const allowImages = settings.allow_wall_images === 'true';
  const uploadedPath = publicPathFor(req.file, 'images');
  if (!allowImages && uploadedPath) deleteUpload(uploadedPath);
  const imagePath = allowImages ? uploadedPath : '';
  if (!message && !imagePath) {
    flash(req, 'bad', 'Duvara yazı veya fotoğraf bırakmalısın.');
    return res.redirect('/#wall');
  }
  const approved = settings.wall_auto_approve === 'true' ? 1 : 0;
  getDb().prepare('INSERT INTO wall_posts (name, message, image_path, approved) VALUES (?, ?, ?, ?)')
    .run(name, message, imagePath, approved);
  flash(req, 'ok', approved ? 'Duvara bırakıldı.' : 'Duvar notun admin onayından sonra görünecek.');
  res.redirect('/#wall');
});

module.exports = router;
