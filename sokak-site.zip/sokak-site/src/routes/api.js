const express = require('express');
const { settingsObject } = require('../db');
const spotify = require('../spotify');

const router = express.Router();

router.get('/spotify/status', async (req, res) => {
  try {
    const data = await spotify.getStatus(settingsObject());
    res.json({ ok: true, ...data });
  } catch (err) {
    res.status(200).json({ ok: false, connected: false, error: err.message });
  }
});

router.get('/health', (req, res) => {
  res.json({ ok: true, at: new Date().toISOString() });
});

module.exports = router;
