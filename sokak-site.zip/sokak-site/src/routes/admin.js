const express = require('express');
const { getDb, settingsObject, setSettings, setSetting } = require('../db');
const { checkToken } = require('../csrf');
const { hasAdmin, createAdmin, verifyAdmin, requireAdmin } = require('../auth');
const { imageUpload, audioUpload, publicPathFor, cleanText, toNumber, normalizeUrl, deleteUpload, flash, formatDate } = require('../utils');
const spotify = require('../spotify');

const router = express.Router();

function safeNext(value) {
  const next = String(value || '');
  if (next.startsWith('/admin') && !next.startsWith('//')) return next;
  return '/admin/dashboard';
}

function activeNav(req, name) {
  return req.path.startsWith(`/admin/${name}`) ? 'active' : '';
}

router.use((req, res, next) => {
  res.locals.adminSettings = settingsObject();
  res.locals.activeNav = (name) => activeNav(req, name);
  res.locals.formatDate = formatDate;
  next();
});

router.get('/', (req, res) => {
  if (!hasAdmin()) return res.redirect('/admin/setup');
  if (!req.session.adminId) return res.redirect('/admin/login');
  res.redirect('/admin/dashboard');
});

router.get('/setup', (req, res) => {
  if (hasAdmin()) return res.redirect('/admin/login');
  res.render('admin/setup', { error: null });
});

router.post('/setup', checkToken, (req, res) => {
  if (hasAdmin()) return res.redirect('/admin/login');
  try {
    createAdmin(req.body.username, req.body.password);
    flash(req, 'ok', 'Admin hesabı oluşturuldu. Şimdi giriş yap.');
    res.redirect('/admin/login');
  } catch (err) {
    res.status(400).render('admin/setup', { error: err.message });
  }
});

router.get('/login', (req, res) => {
  if (!hasAdmin()) return res.redirect('/admin/setup');
  res.render('admin/login', { error: null, next: safeNext(req.query.next) });
});

router.post('/login', checkToken, (req, res) => {
  const admin = verifyAdmin(req.body.username, req.body.password);
  if (!admin) {
    return res.status(401).render('admin/login', { error: 'Kullanıcı adı veya şifre yanlış.', next: safeNext(req.body.next) });
  }
  const nextUrl = safeNext(req.body.next);
  req.session.regenerate((err) => {
    if (err) return res.status(500).send('Oturum başlatılamadı.');
    req.session.adminId = admin.id;
    req.session.adminName = admin.username;
    flash(req, 'ok', 'Giriş tamam.');
    res.redirect(nextUrl);
  });
});

router.post('/logout', checkToken, (req, res) => {
  req.session.destroy(() => res.redirect('/admin/login'));
});

router.use(requireAdmin);

router.get('/dashboard', (req, res) => {
  const db = getDb();
  const counts = {
    unreadMessages: db.prepare('SELECT COUNT(*) AS count FROM private_messages WHERE archived = 0').get().count,
    wallWaiting: db.prepare('SELECT COUNT(*) AS count FROM wall_posts WHERE approved = 0 AND hidden = 0').get().count,
    wallVisible: db.prepare('SELECT COUNT(*) AS count FROM wall_posts WHERE approved = 1 AND hidden = 0').get().count,
    collage: db.prepare('SELECT COUNT(*) AS count FROM collage_items').get().count,
    tracks: db.prepare('SELECT COUNT(*) AS count FROM background_tracks').get().count
  };
  const latestMessages = db.prepare('SELECT * FROM private_messages ORDER BY datetime(created_at) DESC LIMIT 5').all();
  const latestWall = db.prepare('SELECT * FROM wall_posts ORDER BY datetime(created_at) DESC LIMIT 5').all();
  res.render('admin/dashboard', { counts, latestMessages, latestWall, spotifyConnected: spotify.isConnected() });
});

const settingKeys = [
  'site_title', 'site_tagline', 'header_micro', 'search_placeholder',
  'hero_name', 'hero_kicker', 'hero_status', 'hero_here_for', 'hero_body', 'hero_quote',
  'bio_title', 'bio_text', 'wall_title', 'wall_intro', 'private_message_title', 'private_message_intro',
  'spotify_title', 'payment_title', 'iban', 'easy_address', 'payment_note', 'footer_note',
  'admin_brand_note'
];

router.get('/settings', (req, res) => {
  res.render('admin/settings', { settings: settingsObject() });
});

router.post('/settings', checkToken, (req, res) => {
  const values = {};
  settingKeys.forEach((key) => { values[key] = cleanText(req.body[key], key.includes('body') || key.includes('text') || key.includes('intro') ? 2500 : 300); });
  values.wall_auto_approve = req.body.wall_auto_approve ? 'true' : 'false';
  values.allow_wall_images = req.body.allow_wall_images ? 'true' : 'false';
  values.allow_messages = req.body.allow_messages ? 'true' : 'false';
  setSettings(values);
  flash(req, 'ok', 'Site yazıları ve ayarları kaydedildi.');
  res.redirect('/admin/settings');
});

function parseCollage(body, file, existing = {}) {
  const variant = ['photo', 'profile', 'sticker', 'note', 'poster'].includes(body.variant) ? body.variant : 'photo';
  return {
    title: cleanText(body.title, 120),
    subtitle: cleanText(body.subtitle, 160),
    body: cleanText(body.body, 900),
    image_path: file ? publicPathFor(file, 'images') : (existing.image_path || ''),
    link_url: normalizeUrl(body.link_url),
    x: toNumber(body.x, existing.x ?? 10, 0, 95),
    y: toNumber(body.y, existing.y ?? 10, 0, 95),
    w: toNumber(body.w, existing.w ?? 26, 8, 80),
    rotation: toNumber(body.rotation, existing.rotation ?? 0, -35, 35),
    z: Math.round(toNumber(body.z, existing.z ?? 1, 0, 99)),
    variant,
    enabled: body.enabled ? 1 : 0
  };
}

router.get('/collage', (req, res) => {
  const items = getDb().prepare('SELECT * FROM collage_items ORDER BY z ASC, id ASC').all();
  res.render('admin/collage', { items });
});

router.get('/collage/new', (req, res) => {
  res.render('admin/collage-form', { item: null, action: '/admin/collage/new' });
});

router.post('/collage/new', imageUpload.single('image'), checkToken, (req, res) => {
  const item = parseCollage(req.body, req.file);
  getDb().prepare(`
    INSERT INTO collage_items (title, subtitle, body, image_path, link_url, x, y, w, rotation, z, variant, enabled)
    VALUES (@title, @subtitle, @body, @image_path, @link_url, @x, @y, @w, @rotation, @z, @variant, @enabled)
  `).run(item);
  flash(req, 'ok', 'Kolaj parçası eklendi.');
  res.redirect('/admin/collage');
});

router.get('/collage/:id/edit', (req, res) => {
  const item = getDb().prepare('SELECT * FROM collage_items WHERE id = ?').get(req.params.id);
  if (!item) return res.status(404).send('Bulunamadı.');
  res.render('admin/collage-form', { item, action: `/admin/collage/${item.id}/edit` });
});

router.post('/collage/:id/edit', imageUpload.single('image'), checkToken, (req, res) => {
  const existing = getDb().prepare('SELECT * FROM collage_items WHERE id = ?').get(req.params.id);
  if (!existing) return res.status(404).send('Bulunamadı.');
  const item = parseCollage(req.body, req.file, existing);
  if (req.file && existing.image_path) deleteUpload(existing.image_path);
  getDb().prepare(`
    UPDATE collage_items SET
      title = @title,
      subtitle = @subtitle,
      body = @body,
      image_path = @image_path,
      link_url = @link_url,
      x = @x,
      y = @y,
      w = @w,
      rotation = @rotation,
      z = @z,
      variant = @variant,
      enabled = @enabled,
      updated_at = CURRENT_TIMESTAMP
    WHERE id = @id
  `).run({ ...item, id: existing.id });
  flash(req, 'ok', 'Kolaj parçası güncellendi.');
  res.redirect('/admin/collage');
});

router.post('/collage/:id/delete', checkToken, (req, res) => {
  const item = getDb().prepare('SELECT * FROM collage_items WHERE id = ?').get(req.params.id);
  if (item) {
    deleteUpload(item.image_path);
    getDb().prepare('DELETE FROM collage_items WHERE id = ?').run(req.params.id);
  }
  flash(req, 'ok', 'Kolaj parçası silindi.');
  res.redirect('/admin/collage');
});

router.post('/collage/:id/toggle', checkToken, (req, res) => {
  getDb().prepare('UPDATE collage_items SET enabled = CASE enabled WHEN 1 THEN 0 ELSE 1 END WHERE id = ?').run(req.params.id);
  res.redirect('/admin/collage');
});

router.get('/wall', (req, res) => {
  const posts = getDb().prepare('SELECT * FROM wall_posts ORDER BY datetime(created_at) DESC').all();
  res.render('admin/wall', { posts });
});

router.post('/wall/:id/approve', checkToken, (req, res) => {
  getDb().prepare('UPDATE wall_posts SET approved = 1, hidden = 0 WHERE id = ?').run(req.params.id);
  res.redirect('/admin/wall');
});

router.post('/wall/:id/hide', checkToken, (req, res) => {
  getDb().prepare('UPDATE wall_posts SET hidden = CASE hidden WHEN 1 THEN 0 ELSE 1 END WHERE id = ?').run(req.params.id);
  res.redirect('/admin/wall');
});

router.post('/wall/:id/delete', checkToken, (req, res) => {
  const post = getDb().prepare('SELECT * FROM wall_posts WHERE id = ?').get(req.params.id);
  if (post) {
    deleteUpload(post.image_path);
    getDb().prepare('DELETE FROM wall_posts WHERE id = ?').run(req.params.id);
  }
  res.redirect('/admin/wall');
});

router.get('/messages', (req, res) => {
  const messages = getDb().prepare('SELECT * FROM private_messages ORDER BY archived ASC, datetime(created_at) DESC').all();
  res.render('admin/messages', { messages });
});

router.post('/messages/:id/archive', checkToken, (req, res) => {
  getDb().prepare('UPDATE private_messages SET archived = CASE archived WHEN 1 THEN 0 ELSE 1 END WHERE id = ?').run(req.params.id);
  res.redirect('/admin/messages');
});

router.post('/messages/:id/delete', checkToken, (req, res) => {
  getDb().prepare('DELETE FROM private_messages WHERE id = ?').run(req.params.id);
  res.redirect('/admin/messages');
});

router.get('/socials', (req, res) => {
  const socials = getDb().prepare('SELECT * FROM social_links ORDER BY sort_order ASC, id ASC').all();
  res.render('admin/socials', { socials });
});

router.post('/socials/add', checkToken, (req, res) => {
  getDb().prepare('INSERT INTO social_links (service, label, url, sort_order, enabled) VALUES (?, ?, ?, ?, ?)')
    .run(cleanText(req.body.service, 80), cleanText(req.body.label, 100), normalizeUrl(req.body.url), Math.round(toNumber(req.body.sort_order, 99, 0, 999)), req.body.enabled ? 1 : 0);
  flash(req, 'ok', 'Sosyal link eklendi.');
  res.redirect('/admin/socials');
});

router.post('/socials/:id/update', checkToken, (req, res) => {
  getDb().prepare('UPDATE social_links SET service = ?, label = ?, url = ?, sort_order = ?, enabled = ? WHERE id = ?')
    .run(cleanText(req.body.service, 80), cleanText(req.body.label, 100), normalizeUrl(req.body.url), Math.round(toNumber(req.body.sort_order, 99, 0, 999)), req.body.enabled ? 1 : 0, req.params.id);
  flash(req, 'ok', 'Sosyal link güncellendi.');
  res.redirect('/admin/socials');
});

router.post('/socials/:id/delete', checkToken, (req, res) => {
  getDb().prepare('DELETE FROM social_links WHERE id = ?').run(req.params.id);
  res.redirect('/admin/socials');
});

router.get('/music', (req, res) => {
  const tracks = getDb().prepare('SELECT * FROM background_tracks ORDER BY is_active DESC, datetime(created_at) DESC').all();
  res.render('admin/music', { tracks });
});

router.post('/music/add', audioUpload.single('audio'), checkToken, (req, res) => {
  const audioPath = publicPathFor(req.file, 'audio');
  const externalUrl = normalizeUrl(req.body.external_url);
  if (!audioPath && !externalUrl) {
    flash(req, 'bad', 'MP3 yükle veya direkt audio URL gir.');
    return res.redirect('/admin/music');
  }
  const makeActive = req.body.is_active ? 1 : 0;
  const db = getDb();
  const tx = db.transaction(() => {
    if (makeActive) db.prepare('UPDATE background_tracks SET is_active = 0').run();
    db.prepare('INSERT INTO background_tracks (title, artist, audio_path, external_url, is_active, volume) VALUES (?, ?, ?, ?, ?, ?)')
      .run(cleanText(req.body.title, 120) || 'Adsız parça', cleanText(req.body.artist, 120), audioPath, externalUrl, makeActive, toNumber(req.body.volume, 0.45, 0, 1));
  });
  tx();
  flash(req, 'ok', 'Arka plan müziği eklendi.');
  res.redirect('/admin/music');
});

router.post('/music/:id/activate', checkToken, (req, res) => {
  const db = getDb();
  const tx = db.transaction(() => {
    db.prepare('UPDATE background_tracks SET is_active = 0').run();
    db.prepare('UPDATE background_tracks SET is_active = 1 WHERE id = ?').run(req.params.id);
  });
  tx();
  res.redirect('/admin/music');
});

router.post('/music/:id/delete', checkToken, (req, res) => {
  const track = getDb().prepare('SELECT * FROM background_tracks WHERE id = ?').get(req.params.id);
  if (track) {
    deleteUpload(track.audio_path);
    getDb().prepare('DELETE FROM background_tracks WHERE id = ?').run(req.params.id);
  }
  res.redirect('/admin/music');
});

router.post('/music/:id/volume', checkToken, (req, res) => {
  getDb().prepare('UPDATE background_tracks SET volume = ? WHERE id = ?').run(toNumber(req.body.volume, 0.45, 0, 1), req.params.id);
  res.redirect('/admin/music');
});

router.get('/spotify', (req, res) => {
  res.render('admin/spotify', {
    connected: spotify.isConnected(),
    credentialsAvailable: spotify.credentialsAvailable(),
    redirectUri: spotify.getRedirectUri(),
    scopes: spotify.scopes,
    settings: settingsObject()
  });
});

router.post('/spotify/settings', checkToken, (req, res) => {
  setSetting('spotify_playlist_id', cleanText(req.body.spotify_playlist_id, 250));
  flash(req, 'ok', 'Spotify playlist ayarı kaydedildi.');
  res.redirect('/admin/spotify');
});

router.get('/spotify/login', (req, res) => {
  if (!spotify.credentialsAvailable()) {
    flash(req, 'bad', 'Önce .env içine SPOTIFY_CLIENT_ID ve SPOTIFY_CLIENT_SECRET yazmalısın.');
    return res.redirect('/admin/spotify');
  }
  const state = spotify.randomState();
  req.session.spotifyState = state;
  res.redirect(spotify.buildAuthUrl(state));
});

router.get('/spotify/callback', async (req, res) => {
  try {
    if (!req.query.state || req.query.state !== req.session.spotifyState) {
      throw new Error('Spotify güvenlik kodu eşleşmedi.');
    }
    if (!req.query.code) throw new Error('Spotify kodu gelmedi.');
    await spotify.exchangeCode(req.query.code);
    delete req.session.spotifyState;
    flash(req, 'ok', 'Spotify bağlandı.');
  } catch (err) {
    flash(req, 'bad', err.message);
  }
  res.redirect('/admin/spotify');
});

router.post('/spotify/disconnect', checkToken, (req, res) => {
  spotify.clearTokens();
  flash(req, 'ok', 'Spotify bağlantısı kaldırıldı.');
  res.redirect('/admin/spotify');
});

module.exports = router;
