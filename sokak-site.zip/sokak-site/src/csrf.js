const crypto = require('crypto');

function ensureToken(req, res, next) {
  if (req.session && !req.session.csrfToken) {
    req.session.csrfToken = crypto.randomBytes(32).toString('hex');
  }
  res.locals.csrfToken = req.session ? req.session.csrfToken : '';
  next();
}

function checkToken(req, res, next) {
  const expected = req.session && req.session.csrfToken;
  const actual = req.body && req.body._csrf;
  if (!expected || !actual || expected !== actual) {
    const wantsJson = req.accepts(['html', 'json']) === 'json';
    if (wantsJson) return res.status(403).json({ ok: false, error: 'CSRF token gecersiz.' });
    return res.status(403).send('Form güvenlik doğrulaması geçersiz. Sayfayı yenileyip tekrar dene.');
  }
  next();
}

module.exports = { ensureToken, checkToken };
