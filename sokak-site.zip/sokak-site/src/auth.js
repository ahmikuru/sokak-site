const bcrypt = require('bcryptjs');
const { getDb } = require('./db');

function hasAdmin() {
  return getDb().prepare('SELECT COUNT(*) AS count FROM admins').get().count > 0;
}

function createAdmin(username, password) {
  const cleanUsername = String(username || '').trim().slice(0, 40);
  if (!cleanUsername || cleanUsername.length < 3) {
    throw new Error('Kullanıcı adı en az 3 karakter olmalı.');
  }
  if (!password || String(password).length < 8) {
    throw new Error('Şifre en az 8 karakter olmalı.');
  }
  if (hasAdmin()) {
    throw new Error('Admin hesabı zaten oluşturulmuş.');
  }
  const hash = bcrypt.hashSync(String(password), 12);
  getDb().prepare('INSERT INTO admins (username, password_hash) VALUES (?, ?)').run(cleanUsername, hash);
}

function verifyAdmin(username, password) {
  const admin = getDb().prepare('SELECT * FROM admins WHERE username = ?').get(String(username || '').trim());
  if (!admin) return null;
  const ok = bcrypt.compareSync(String(password || ''), admin.password_hash);
  return ok ? admin : null;
}

function requireAdmin(req, res, next) {
  if (req.session && req.session.adminId) return next();
  const nextUrl = encodeURIComponent(req.originalUrl || '/admin');
  return res.redirect(`/admin/login?next=${nextUrl}`);
}

function attachAdmin(req, res, next) {
  res.locals.adminLoggedIn = Boolean(req.session && req.session.adminId);
  next();
}

module.exports = { hasAdmin, createAdmin, verifyAdmin, requireAdmin, attachAdmin };
