const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const multer = require('multer');

const publicDir = path.join(__dirname, 'public');
const imageDir = path.join(publicDir, 'uploads', 'images');
const audioDir = path.join(publicDir, 'uploads', 'audio');

fs.mkdirSync(imageDir, { recursive: true });
fs.mkdirSync(audioDir, { recursive: true });

function cleanText(value, max = 2000) {
  return String(value ?? '')
    .replace(/\u0000/g, '')
    .replace(/\r\n/g, '\n')
    .trim()
    .slice(0, max);
}

function toNumber(value, fallback, min, max) {
  const n = Number(value);
  if (!Number.isFinite(n)) return fallback;
  return Math.min(max, Math.max(min, n));
}

function normalizeUrl(value) {
  const raw = cleanText(value, 500);
  if (!raw) return '';
  if (/^https?:\/\//i.test(raw)) return raw;
  return `https://${raw}`;
}

function uploadName(file, kind) {
  const extByMime = {
    'image/jpeg': '.jpg',
    'image/png': '.png',
    'image/webp': '.webp',
    'image/gif': '.gif',
    'audio/mpeg': '.mp3',
    'audio/mp3': '.mp3',
    'audio/wav': '.wav',
    'audio/x-wav': '.wav',
    'audio/ogg': '.ogg',
    'audio/mp4': '.m4a',
    'audio/aac': '.aac'
  };
  const ext = extByMime[file.mimetype] || path.extname(file.originalname || '').toLowerCase();
  const rand = crypto.randomBytes(8).toString('hex');
  return `${kind}-${Date.now()}-${rand}${ext}`;
}

const imageUpload = multer({
  storage: multer.diskStorage({
    destination: (req, file, cb) => cb(null, imageDir),
    filename: (req, file, cb) => cb(null, uploadName(file, 'img'))
  }),
  limits: { fileSize: Number(process.env.MAX_IMAGE_MB || 8) * 1024 * 1024 },
  fileFilter: (req, file, cb) => {
    const allowed = ['image/jpeg', 'image/png', 'image/webp', 'image/gif'];
    if (allowed.includes(file.mimetype)) return cb(null, true);
    cb(new Error('Sadece JPG, PNG, WEBP veya GIF yüklenebilir.'));
  }
});

const audioUpload = multer({
  storage: multer.diskStorage({
    destination: (req, file, cb) => cb(null, audioDir),
    filename: (req, file, cb) => cb(null, uploadName(file, 'audio'))
  }),
  limits: { fileSize: Number(process.env.MAX_AUDIO_MB || 25) * 1024 * 1024 },
  fileFilter: (req, file, cb) => {
    const allowed = ['audio/mpeg', 'audio/mp3', 'audio/wav', 'audio/x-wav', 'audio/ogg', 'audio/mp4', 'audio/aac'];
    if (allowed.includes(file.mimetype)) return cb(null, true);
    cb(new Error('Sadece MP3, WAV, OGG, M4A veya AAC yüklenebilir.'));
  }
});

function publicPathFor(file, folder) {
  if (!file) return '';
  return `/uploads/${folder}/${file.filename}`;
}

function deleteUpload(filePath) {
  if (!filePath || !filePath.startsWith('/uploads/')) return;
  const absolute = path.normalize(path.join(publicDir, filePath));
  if (!absolute.startsWith(publicDir)) return;
  fs.unlink(absolute, () => {});
}

function flash(req, type, message) {
  req.session.flash = { type, message };
}

function attachFlash(req, res, next) {
  res.locals.flash = req.session ? req.session.flash : null;
  if (req.session && req.session.flash) delete req.session.flash;
  next();
}

function formatDate(value) {
  try {
    return new Intl.DateTimeFormat('tr-TR', {
      dateStyle: 'medium',
      timeStyle: 'short'
    }).format(new Date(value));
  } catch (e) {
    return value;
  }
}

module.exports = {
  publicDir,
  imageUpload,
  audioUpload,
  publicPathFor,
  deleteUpload,
  cleanText,
  toNumber,
  normalizeUrl,
  flash,
  attachFlash,
  formatDate
};
