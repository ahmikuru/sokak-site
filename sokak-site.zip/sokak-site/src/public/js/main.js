(function () {
  function $(selector, root) {
    return (root || document).querySelector(selector);
  }

  function el(tag, className, text) {
    var node = document.createElement(tag);
    if (className) node.className = className;
    if (text !== undefined) node.textContent = text;
    return node;
  }

  function imageOrFallback(src, alt) {
    if (!src) {
      var box = el('div', 'spotify-image-fallback', '♪');
      return box;
    }
    var img = document.createElement('img');
    img.src = src;
    img.alt = alt || '';
    img.loading = 'lazy';
    return img;
  }

  function renderSpotify(data) {
    var widget = $('#spotifyWidget');
    if (!widget) return;
    widget.innerHTML = '';
    if (!data || !data.ok || !data.connected) {
      widget.appendChild(el('div', 'spotify-empty', 'Spotify henüz bağlı değil. Admin panelden bağlayınca canlı müzik akışı burada görünür.'));
      return;
    }

    if (data.current) {
      var current = el('a', 'spotify-current');
      current.href = data.current.url || '#';
      current.target = '_blank';
      current.rel = 'noopener noreferrer';
      current.appendChild(imageOrFallback(data.current.image, data.current.name));
      var copy = el('div');
      copy.appendChild(el('p', 'section-label', data.current.isPlaying ? 'şu an çalıyor' : 'son bilinen şarkı'));
      copy.appendChild(el('h3', '', data.current.name || 'Bilinmeyen parça'));
      copy.appendChild(el('p', '', data.current.artist || ''));
      if (data.current.album) copy.appendChild(el('p', '', data.current.album));
      current.appendChild(copy);
      widget.appendChild(current);
    } else {
      widget.appendChild(el('div', 'spotify-empty', 'Şu an aktif çalan şarkı görünmüyor; son çalınanlar aşağıda.'));
    }

    if (data.featuredPlaylist) {
      var title = el('h3', '', 'Öne çıkan playlist');
      title.style.marginTop = '22px';
      widget.appendChild(title);
      var featuredGrid = el('div', 'spotify-grid');
      featuredGrid.appendChild(playlistTile(data.featuredPlaylist));
      widget.appendChild(featuredGrid);
    }

    if (data.recent && data.recent.length) {
      var recentTitle = el('h3', '', 'Son çalınanlar');
      recentTitle.style.marginTop = '22px';
      widget.appendChild(recentTitle);
      var grid = el('div', 'spotify-grid');
      data.recent.forEach(function (track) {
        var tile = el('a', 'spotify-tile');
        tile.href = track.url || '#';
        tile.target = '_blank';
        tile.rel = 'noopener noreferrer';
        tile.appendChild(imageOrFallback(track.image, track.name));
        tile.appendChild(el('strong', '', track.name || 'Bilinmeyen'));
        tile.appendChild(el('span', '', track.artist || ''));
        grid.appendChild(tile);
      });
      widget.appendChild(grid);
    }

    if (data.playlists && data.playlists.length) {
      var listTitle = el('h3', '', 'Playlistler');
      listTitle.style.marginTop = '22px';
      widget.appendChild(listTitle);
      var playlistGrid = el('div', 'spotify-grid');
      data.playlists.forEach(function (playlist) {
        playlistGrid.appendChild(playlistTile(playlist));
      });
      widget.appendChild(playlistGrid);
    }
  }

  function playlistTile(playlist) {
    var tile = el('a', 'spotify-tile');
    tile.href = playlist.url || '#';
    tile.target = '_blank';
    tile.rel = 'noopener noreferrer';
    tile.appendChild(imageOrFallback(playlist.image, playlist.name));
    tile.appendChild(el('strong', '', playlist.name || 'Playlist'));
    var meta = [];
    if (playlist.owner) meta.push(playlist.owner);
    if (playlist.total !== null && playlist.total !== undefined) meta.push(playlist.total + ' parça');
    tile.appendChild(el('span', '', meta.join(' • ')));
    return tile;
  }

  function loadSpotify() {
    var widget = $('#spotifyWidget');
    if (!widget) return;
    fetch('/api/spotify/status', { headers: { Accept: 'application/json' } })
      .then(function (res) { return res.json(); })
      .then(renderSpotify)
      .catch(function () {
        widget.innerHTML = '';
        widget.appendChild(el('div', 'spotify-empty', 'Spotify bilgisi şu an alınamadı.'));
      });
  }

  function setupMusicDock() {
    var dock = $('[data-music-dock]');
    if (!dock) return;
    var audio = $('#bgAudio');
    var btn = $('[data-music-toggle]', dock);
    if (!audio || !btn) return;
    var volume = Number(dock.getAttribute('data-volume'));
    audio.volume = Number.isFinite(volume) ? Math.max(0, Math.min(1, volume)) : 0.45;
    btn.addEventListener('click', function () {
      if (audio.paused) {
        audio.play().then(function () {
          btn.textContent = 'PAUSE BG MUSIC';
        }).catch(function () {
          btn.textContent = 'PLAY ENGELLENDİ - TEKRAR DENE';
        });
      } else {
        audio.pause();
        btn.textContent = 'PLAY BG MUSIC';
      }
    });
  }

  function setupWallFilter() {
    var input = $('[data-filter-wall]');
    var list = $('[data-wall-list]');
    if (!input || !list) return;
    input.addEventListener('input', function () {
      var term = input.value.trim().toLowerCase();
      list.querySelectorAll('[data-wall-note]').forEach(function (note) {
        note.style.display = note.textContent.toLowerCase().includes(term) ? '' : 'none';
      });
    });
  }

  document.addEventListener('DOMContentLoaded', function () {
    loadSpotify();
    setupMusicDock();
    setupWallFilter();
    window.setInterval(loadSpotify, 60000);
  });
})();
