const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const readline = require('readline');

const root = path.join(__dirname, '..');
const envPath = path.join(root, '.env');
const examplePath = path.join(root, '.env.example');

function ask(rl, q, fallback = '') {
  return new Promise((resolve) => {
    const suffix = fallback ? ` (${fallback})` : '';
    rl.question(`${q}${suffix}: `, (answer) => resolve((answer || fallback).trim()));
  });
}

(async () => {
  if (fs.existsSync(envPath)) {
    console.log('.env zaten var. Istersen dosyayi elle duzenleyebilirsin.');
    return;
  }

  const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
  console.log('\nSokak Kolaj Site - ilk ayar\n');
  const port = await ask(rl, 'Port', '3000');
  const host = await ask(rl, 'Sadece bu bilgisayarda acilsin diye HOST', '127.0.0.1');
  const baseUrl = await ask(rl, 'Site adresi', `http://${host}:${port}`);
  rl.close();

  const secret = crypto.randomBytes(48).toString('hex');
  const example = fs.existsSync(examplePath) ? fs.readFileSync(examplePath, 'utf8') : '';
  const env = example
    .replace(/^SESSION_SECRET=.*$/m, `SESSION_SECRET=${secret}`)
    .replace(/^PORT=.*$/m, `PORT=${port}`)
    .replace(/^HOST=.*$/m, `HOST=${host}`)
    .replace(/^BASE_URL=.*$/m, `BASE_URL=${baseUrl}`)
    .replace(/^SPOTIFY_REDIRECT_URI=.*$/m, `SPOTIFY_REDIRECT_URI=${baseUrl.replace(/\/$/, '')}/admin/spotify/callback`);

  fs.writeFileSync(envPath, env, 'utf8');
  console.log('\n[OK] .env olusturuldu. Simdi npm install ve npm run dev calistirabilirsin.');
  console.log('Admin hesabi icin site acilinca /admin/setup sayfasindan kendi kullanici adi ve sifreni olusturacaksin.\n');
})().catch((err) => {
  console.error(err);
  process.exit(1);
});
