# Sokak Kolaj Site

Bu proje; eski web / sokak dergisi / dağınık kolaj havasında, admin panelli kişisel site olarak hazırlandı.

## Özellikler

- Ana sayfada dağınık fotoğraf/yazı kolajı
- Admin panelden tüm ana yazıları değiştirme
- Kolaj parçalarını tek tek ekleme, silme, gizleme, fotoğraf yükleme
- Spotify: şu an dinlediğin şarkı, son dinlediklerin, playlist kartları
- Ziyaretçiden gizli mesaj alma
- Herkese açık anonim/isimli duvar yazıları
- Duvara fotoğraf/GIF yükleme
- Admin panelden duvar yazısı onaylama, gizleme, silme
- IBAN, Kolay Adres ve sosyal hesap linkleri
- Seçilebilir arka plan müziği
- Yerel SQLite veritabanı: ekstra veritabanı kurmana gerek yok

## En kolay kurulum

### Windows

1. Node.js 20 veya üstünü kur.
2. Bu klasörü ZIP'ten çıkar.
3. `start-windows.bat` dosyasına çift tıkla.
4. İlk açılışta `.env` dosyası oluşturulur ve gerekli paketler kurulur.
5. Tarayıcıda `http://127.0.0.1:3000` açılır.
6. Admin panel: `http://127.0.0.1:3000/admin`
7. İlk girişte `/admin/setup` sayfası açılır; kendi admin kullanıcı adını ve şifreni oluştur.

### Mac / Linux

Terminalde klasöre gir:

```bash
chmod +x start-mac-linux.sh
./start-mac-linux.sh
```

Manuel çalıştırmak istersen:

```bash
npm run setup
npm install
npm run dev
```

## Admin panelde ne yapacaksın?

- `/admin/settings`: site adı, bio, IBAN, kolay adres, duvar/mesaj yazıları
- `/admin/collage`: ana sayfadaki fotoğraf ve yazı parçaları
- `/admin/wall`: herkese açık duvar yazıları ve fotoğrafları
- `/admin/messages`: sadece sana gelen gizli mesajlar
- `/admin/socials`: Instagram, TikTok, Letterboxd, Discord, Spotify linkleri
- `/admin/music`: arka plan müziği seçimi
- `/admin/spotify`: Spotify bağlantısı

## Kendi bilgisayarında domain gibi açmak

Tam bir domain satın almadan, bilgisayarında yerel isim verebilirsin.

### Sadece kendi bilgisayarında

`http://127.0.0.1:3000` zaten çalışır.

Yerel alan adı gibi kullanmak için hosts dosyasına şunu ekleyebilirsin:

```text
127.0.0.1 sokak.test
```

Sonra şu adresten açılır:

```text
http://sokak.test:3000
```

Windows hosts dosyası genelde:

```text
C:\Windows\System32\drivers\etc\hosts
```

Mac/Linux hosts dosyası:

```text
/etc/hosts
```

### Ev Wi-Fi ağındaki diğer cihazlardan açmak

`.env` içinde:

```text
HOST=0.0.0.0
BASE_URL=http://BILGISAYARIN_YEREL_IP_ADRESI:3000
```

Sonra bilgisayarının yerel IP adresiyle telefondan veya aynı ağdaki cihazdan açabilirsin.

Örnek:

```text
http://192.168.1.34:3000
```

Windows güvenlik duvarı port 3000 için izin isteyebilir.

## Gerçek domain ile internete açmak

Bunu sonra yapmanı öneririm. Seçenekler:

1. Domain satın alıp DNS A kaydını ev internetinin IP adresine yönlendirmek.
2. Modemden port forwarding yapmak.
3. Statik IP yoksa Cloudflare Tunnel veya benzeri tünel kullanmak.
4. İnternete açınca HTTPS kullanmak.
5. Admin şifreni güçlü seçmek ve `.env` içindeki `SESSION_SECRET` değerini değiştirmek.

## Spotify kurulumu

1. Spotify Developer Dashboard'da yeni uygulama oluştur.
2. Redirect URI olarak şunu ekle:

```text
http://127.0.0.1:3000/admin/spotify/callback
```

Eğer site adresini değiştirdiysen `.env` içindeki `SPOTIFY_REDIRECT_URI` ile aynı olmalı.

3. `.env` dosyasına şunları yaz:

```text
SPOTIFY_CLIENT_ID=...
SPOTIFY_CLIENT_SECRET=...
SPOTIFY_REDIRECT_URI=http://127.0.0.1:3000/admin/spotify/callback
```

4. Siteyi kapatıp tekrar aç.
5. `/admin/spotify` sayfasına gir ve `Spotify bağla` butonuna bas.

Not: Bu site Spotify şarkılarını arka planda yayınlamaz; Spotify API ile sadece ne dinlediğini ve playlist bilgilerini gösterir. Arka plan müziği için kendi MP3 dosyanı yüklemen veya direkt audio URL vermen gerekir.

## Arka plan müziği

Admin panelde `/admin/music` sayfasından MP3/WAV/OGG/M4A/AAC yükleyebilirsin.

Tarayıcılar sesli medyayı çoğu zaman otomatik başlatmadığı için ziyaretçi `PLAY BG MUSIC` butonuna basınca çalar.

## Veriler nerede duruyor?

- Veritabanı: `data/site.sqlite`
- Oturum verisi: `data/sessions.sqlite`
- Fotoğraflar: `src/public/uploads/images`
- Müzikler: `src/public/uploads/audio`

Yedek almak için bu dosya/klasörleri sakla.

## Docker ile çalıştırma

```bash
cp .env.example .env
# .env dosyasını düzenle
npm run setup
# veya .env'i elle doldur

docker compose up --build
```

Site:

```text
http://127.0.0.1:3000
```

## Güvenlik notları

- SVG upload kapalı; JPG/PNG/WEBP/GIF kabul edilir.
- Public duvar ve mesaj formlarında hız limiti vardır.
- Admin panel girişlidir.
- İnternete açmadan önce güçlü admin şifresi, güçlü `SESSION_SECRET`, HTTPS ve düzenli yedek kullan.
